package controller;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.mapping.Map;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HelloController {
	@RequestMapping(value = "/hello.sms", method = RequestMethod.GET)
	public  ModelAndView hello(HttpServletRequest req, HttpServletResponse res)
			throws Exception {

		String name = req.getParameter("name");
		String page = "hellosuccess";
		Map m = new HashMap();
		m.put("msg", "Hello...Mr.." + name);

		ModelAndView mav = new ModelAndView(page, m);
		return mav;
	}

}
