package beans;

public interface Car {
public void drive();
}
