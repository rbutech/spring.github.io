package beans;


public class Audi implements Car{

@Override
	public void drive() {
	System.out.println("safedriver upto 100 kmph");
	}	
	
}
