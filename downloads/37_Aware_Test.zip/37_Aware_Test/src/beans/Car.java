package beans;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

public class Car implements ApplicationContextAware {
	public Car() {
	System.out.println("Car - object");
	}

	private ApplicationContext ap;
	
	@Override
	public void setApplicationContext(ApplicationContext ap)
			throws BeansException {
				this.ap=ap;
	
	}
	public void drive(){
		Engine e=(Engine)	ap.getBean("e");
		System.out.println("Car Audi Drive using Engine="+e.getModelyear());
	}
	
	

}
