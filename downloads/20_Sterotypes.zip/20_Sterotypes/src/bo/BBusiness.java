package bo;

import org.springframework.stereotype.Service;

@Service
public class BBusiness
{
	
	public BBusiness() {
	System.out.println("BBusiness object");
	}

}
