package controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;
import org.springframework.web.servlet.mvc.ParameterizableViewController;

public class RegController extends ParameterizableViewController {

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest req,
			HttpServletResponse res) throws Exception {
		
		
	int id=Integer.parseInt(req.getParameter("id"));
		String name=req.getParameter("name");
		String email=req.getParameter("email");
		String address=req.getParameter("address");
		System.out.println(id);
		System.out.println(name);
		System.out.println(email);
		System.out.println(address);
		
		ModelAndView mav=new ModelAndView();
		mav.setViewName(getViewName());
		mav.addObject("id", id);
		mav.addObject("name",name);
		mav.addObject("email",email);
		mav.addObject("address",address);
		return mav;
	}

}
