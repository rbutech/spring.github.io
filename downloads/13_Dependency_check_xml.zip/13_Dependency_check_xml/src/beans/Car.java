package beans;

public class Car {
private Engine engine;
private String carname;

public void setCarname(String carname) {
	this.carname = carname;
}
public void setEngine(Engine engine) {
	this.engine = engine;
}
public void printData(){
	System.out.println("CarName="+carname);
	System.out.println("Engine="+engine.getModelyear());
}

}
