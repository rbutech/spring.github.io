package com.ds.controller;

import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ds.bo.StudentBo;
import com.ds.dao.Student;

public class StudentController {

	public static void main(String[] args) {

		ApplicationContext ap = new ClassPathXmlApplicationContext(
				"resources/spring.xml");

		Scanner sc = new Scanner(System.in);
		System.out
				.println("1 for save 2 for update 3 for delete 4 for select one 5 for select all ");

		int i = sc.nextInt();
		switch (i) {
		case 1:
			System.out.println("Enter id=");
			int id = sc.nextInt();
			System.out.println("Enter Name=");
			String name = sc.next();
			System.out.println("Enter Email=");
			String email = sc.next();
			System.out.println("Enter Address=");
			String address = sc.next();
			StudentBo st = (StudentBo) ap.getBean("bo");
			int res = st.joinStudent(id, name, email, address);
			if (res != 0)
				System.out.println("Insertion success");
			else
				System.out.println("fail");
			break;
		case 2:
			System.out.println("Enter id=");
			int id1 = sc.nextInt();
			System.out.println("Enter Name=");
			String name1 = sc.next();
			System.out.println("Enter Email=");
			String email1 = sc.next();
			System.out.println("Enter Address=");
			String address1 = sc.next();
			StudentBo st1 = (StudentBo) ap.getBean("bo");
			int res1 = st1.updateExStudent(id1, name1, email1, address1);
			if (res1 != 0)
				System.out.println("Update success");
			else
				System.out.println("update fail");
			break;

		case 3:
			System.out.println("Enter id=");
			int id2 = sc.nextInt();
			StudentBo bo = (StudentBo) ap.getBean("bo");
			int res2 = bo.deleteStudent(id2);
			if (res2 != 0)
				System.out.println("delete success");
			else
				System.out.println("delete fail");
			break;

		case 4:
			System.out.println("Enter id=");
			int id3 = sc.nextInt();
			StudentBo bo1 = (StudentBo) ap.getBean("bo");
			Student student=bo1.getStudenObject(id3);
			System.out.println(student.getId());
			System.out.println(student.getName());
			System.out.println(student.getEmail());
			System.out.println(student.getAddress());
			
			/*Map map = bo1.getStudentById(id3);

			Set keys = map.keySet();
			for (Object key : keys) {
				Object value = map.get(key);
				System.out.println("Column=" + key + "||value=" + value);
			}*/
			break;

		case 5:
			StudentBo bo2 = (StudentBo) ap.getBean("bo");
			List list = bo2.getAllStudents();
			for (Object obj : list) {
				Map map1 = (Map) obj;
				Set keys1 = map1.keySet();
				for (Object key : keys1) {
					Object value = map1.get(key);
					System.out.println("Column=" + key + "||value=" + value);
				}
			}
			break;

		}

	}
}