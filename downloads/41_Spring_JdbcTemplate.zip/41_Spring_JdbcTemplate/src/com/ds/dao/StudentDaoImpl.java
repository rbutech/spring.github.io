package com.ds.dao;

import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;

public class StudentDaoImpl implements StudentDaoInterface {

	private JdbcTemplate template;

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	@Override
	public int save(int id, String name, String email, String address) {

		Object[] arg = new Object[] { id, name, email, address };
		int i = template.update("insert into DS_STUDENT_SPR values(?,?,?,?)", arg);
		return i;
	}

	@Override
	public int update(int id, String name, String email, String address) {
		Object[] arg = new Object[] { name, email, address, id };
		int i = template.update(
				"update DS_STUDENT_SPR set name=?,email=?,address=? where id=?", arg);
		return i;
	}

	@Override
	public int delete(int id) {
		Object[] arg = new Object[] { id };
		int i = template.update("delete DS_STUDENT_SPR where id=?", arg);
		return i;
	}

	@Override
	public Map findbyPk(int id) {
		Object[] arg = new Object[] { id };
		Map map = template.queryForMap("select * from DS_STUDENT_SPR where id=?", arg);
		return map;
	}

	@Override
	public List findAll() {
		List list = template.queryForList("select * from DS_STUDENT_SPR");
		return list;
	}

	@Override
	public Student findbyObject(int id) {
	Student student=(Student)template.queryForObject("select * from DS_STUDENT_SPR where id="+id, new StudentMapper());
		return student;
	}
	
	
	
}

