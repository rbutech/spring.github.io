package com.ds.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class StudentMapper implements RowMapper {

	@Override
	public Object mapRow(ResultSet rs, int arg) throws SQLException {
		int id = rs.getInt(1);
		String name = rs.getString(2);
		String email = rs.getString(3);
		String address = rs.getString(4);
		
		Student student = new Student();
		student.setId(id);
		student.setName(name);
		student.setEmail(email);
		student.setAddress(address);
		return student;
	}

}
