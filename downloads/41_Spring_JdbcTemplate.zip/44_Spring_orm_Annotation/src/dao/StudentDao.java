package dao;

import beans.Student;

public interface StudentDao {
public int save(Student student);
}
