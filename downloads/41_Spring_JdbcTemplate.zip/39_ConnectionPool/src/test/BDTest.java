package test;

import java.sql.Connection;

import org.apache.tomcat.dbcp.dbcp.BasicDataSource;

public class BDTest {
	public static void main(String[] args)throws Exception {
		
		BasicDataSource bds=new  BasicDataSource();
		bds.setDriverClassName("oracle.jdbc.OracleDriver");
		bds.setUrl("jdbc:oracle:thin:@localhost:1521:xe");
		bds.setUsername("system");
		bds.setPassword("manager");
		bds.setMaxActive(15);
		bds.setMaxWait(1000*10);
				

		
		for(int i=0;i<25000;i++)
		{
		Connection con=bds.getConnection();
		System.out.println(con+":"+i);
		con.close();
		}
		
		
		
	}

}
