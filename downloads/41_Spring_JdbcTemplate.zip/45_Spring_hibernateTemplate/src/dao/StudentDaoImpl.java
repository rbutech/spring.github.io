package dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.HibernateTemplate;

import beans.Student;

public class StudentDaoImpl implements StudentDao {

	private HibernateTemplate template;

	public void setTemplate(HibernateTemplate template) {
		this.template = template;
	}

	@Override
	public int save(Student student) {
		int pk = (Integer) template.save(student);
		return pk;
	}

	@Override
	public boolean update(Student student) {

		try {
			template.update(student);

		} catch (Exception e) {
			return false;
		}
		return true;

	}

	@Override
	public boolean delete(Student student) {
		try {
			template.delete(student);

		} catch (Exception e) {
			return false;
		}
		return true;

	}

	@Override
	public Student findByPk(Integer pk) {

		Student st = (Student) template.get(Student.class, pk);

		return st;
	}

	@Override
	public List<Student> findall(Integer pk) {
		return 	template.find("from Student");
	//	DetachedCriteria cr=DetachedCriteria.forClass(Student.class);
	/*return	template.findByCriteria(cr);*/
/*	List<Object[]> list=template.execute(new HibernateCallback() {
		
		@Override
		public Object doInHibernate(Session session)
				throws HibernateException, SQLException {
				List<Object[]> list=(List<Object[]>)session.createSQLQuery("select * from student");
					session.close();
			return list;
		}
		});
		
			List<Student> l=new ArrayList<Student>();
			
			for(Object[] val:list)
			{
				Student st=new Student();
				st.setId((Integer)val[0]);
				st.setName(val[1].toString());
				st.setEmail(val[2].toString());
				st.setAddress(val[3].toString());
			l.add(st);
			}
	
		return l;*/
	}
	
	

}
