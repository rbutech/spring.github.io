package com.ds.bo;

import java.util.List;
import java.util.Map;

import com.ds.dao.Student;

public interface StudentBo {
	public int joinStudent(int id,String name,String email,String adddress);
	public int updateExStudent(int id,String name,String email,String adddress);
	public int deleteStudent(int id);
	public Map getStudentById(int id);
	public List getAllStudents();
	public Student getStudenObject(int id);

}
