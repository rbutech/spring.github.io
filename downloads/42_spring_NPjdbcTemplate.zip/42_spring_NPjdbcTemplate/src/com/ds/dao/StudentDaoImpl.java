package com.ds.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

public class StudentDaoImpl implements StudentDaoInterface {

	private NamedParameterJdbcTemplate template;

	public void setTemplate(NamedParameterJdbcTemplate template) {
		this.template = template;
	}

	@Override
	public int save(int id, String name, String email, String address) {
		Map m = new HashMap();
		m.put("id", id);
		m.put("name", name);
		m.put("email", email);
		m.put("address", address);
		int i = template.update("insert into DS_STUDENT_SPR(id,name,email,address) values(:id,:name,:email,:address)",
				m);
		return i;
	}

	@Override
	public int update(int id, String name, String email, String address) {

		Map m = new HashMap();
		m.put("id", id);
		m.put("name", name);
		m.put("email", email);
		m.put("address", address);
		int i = template.update("update DS_STUDENT_SPR set name=:name,email=:email,address=:address where id=:id", m);
		return i;
	}

	@Override
	public int delete(int id) {
		Map m = new HashMap();
		m.put("id", id);
		int i = template.update("delete DS_STUDENT_SPR where id=:id", m);
		return i;
	}

	@Override
	public Map findbyPk(int id) {
		Map m = new HashMap();
		m.put("id", id);
		Map map = template.queryForMap("select * from student where id=:id", m);
		return map;
	}

	@Override
	public List findAll() {
		Map m = new HashMap();
		List list = template.queryForList("select * from DS_STUDENT_SPR", m);
		return list;
	}

	@Override
	public Student findbyObject(int id) {
		Map m = new HashMap();
		m.put("id", id);

		Student student = (Student) template.queryForObject("select * from DS_STUDENT_SPR where id=:id", m,
				new StudentMapper());
		return student;
	}

}
