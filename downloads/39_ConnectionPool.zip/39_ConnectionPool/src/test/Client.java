package test;

import java.sql.Connection;

import javax.sql.DataSource;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Client
{
	
	public static void main(String[] args)throws Exception {
		
		ApplicationContext ap=new ClassPathXmlApplicationContext("resources/spring.xml");
	
	DataSource ds=(DataSource)	ap.getBean("bds");
	
	for(int i=0;i<500;i++){
	Connection con=ds.getConnection();
	System.out.println(con+":"+i);
	con.close();
	}
	}

}
