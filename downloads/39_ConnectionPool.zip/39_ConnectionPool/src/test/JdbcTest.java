package test;

import java.sql.Connection;
import java.sql.DriverManager;

public class JdbcTest {
public static void main(String[] args) {
	
	
	try{
		Class.forName("oracle.jdbc.OracleDriver");
		for(int i=0;i<25;i++){
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","manager");
		System.out.println(con+":"+i);
		con.close();
		Thread.sleep(1000*1);
		}
		
	}catch(Exception e){
		e.printStackTrace();
	}
	
	
}
}
