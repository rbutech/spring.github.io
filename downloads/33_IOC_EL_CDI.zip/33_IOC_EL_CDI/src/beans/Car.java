package beans;

public class Car {
	private String modelyear;
	private Engine engine;

	public Car(String modelyear,Engine engine) 
	{
		this.modelyear=modelyear;
		this.engine=engine;
	}
	
	
	
	public Engine getEngine() {
		return engine;
	}

	public String getModelyear() {
		return modelyear;
	}

}
