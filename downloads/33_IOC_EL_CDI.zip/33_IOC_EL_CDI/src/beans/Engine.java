package beans;

public class Engine {

	private String modelyear;

	public Engine(String modelyear) 
	{
	this.modelyear=modelyear;
	}
	public String getModelyear() {
		return modelyear;
	}
}
