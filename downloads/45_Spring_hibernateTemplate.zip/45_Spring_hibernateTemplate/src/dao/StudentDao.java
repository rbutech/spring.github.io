package dao;

import java.util.List;

import beans.Student;

public interface StudentDao {
public int save(Student student);
public boolean update(Student student);
public boolean delete(Student student);
public Student findByPk(Integer pk);
public List<Student> findall(Integer pk);
}
