package controller;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import dao.StudentDao;

import beans.Student;

public class Client {
public static void main(String[] args) throws Exception{
	
	Scanner sc=new Scanner(System.in);
	
	System.out.println("Enter Id");
	int id=sc.nextInt();
	System.out.println("Enter name");
	String name=sc.next();
	System.out.println("Enter email");
	String email=sc.next();
	System.out.println("Enter address");
	String address=sc.next();
	
	Student st=new  Student();
	st.setId(id);
	st.setName(name);
	st.setEmail(email);
	st.setAddress(address);
	
	ApplicationContext ap=new ClassPathXmlApplicationContext("resources/spring.xml");
	
	StudentDao dao=(StudentDao)ap.getBean("dao");
	int pk=dao.save(st);
	if(pk!=0)
		System.out.println("ID="+pk);
	else
		System.out.println("failed");


}
}
