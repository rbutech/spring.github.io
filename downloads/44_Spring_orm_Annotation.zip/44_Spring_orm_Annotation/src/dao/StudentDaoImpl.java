package dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import beans.Student;

public class StudentDaoImpl implements StudentDao {

	private SessionFactory factory;
	public void setFactory(SessionFactory factory) {
		this.factory = factory;
	}
	
	
	@Override
	public int save(Student student) {
			Session session=factory.openSession();
			Transaction transaction=session.beginTransaction();
			int pk=(Integer)session.save(student);
			transaction.commit();
			session.close();
			return pk;
	}

}
