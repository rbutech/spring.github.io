package test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import beans.Car;
import beans.Engine;

public class Client {
	public static void main(String[] args) {

		ApplicationContext ap = new ClassPathXmlApplicationContext(
				"resources/car.xml");

		Car c = (Car) ap.getBean("c");
		Car c1 = (Car) ap.getBean("c");
		System.out.println(c==c1);
		System.out.println(c.getClass().getCanonicalName());
		Engine	 eng=c.myEng();
		System.out.println(eng.getModelyear());
	}
}
