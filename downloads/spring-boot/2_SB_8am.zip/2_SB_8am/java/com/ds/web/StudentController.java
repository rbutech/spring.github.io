package com.ds.web;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.ds.service.StudentService;

@RestController
public class StudentController {
	@Autowired
	private StudentService service;
	@Autowired
	private RestTemplate restTemplate;

	public StudentController() {
		System.out.println("StudentController");
	}

	@RequestMapping("/hello")
	public String getMessage() {
		return service.getMessage();
	}

	// @RequestMapping(value = "/reg", method = RequestMethod.POST)
	// create
	@PostMapping(value = "/regStudent")
	public String register(@RequestBody Student student) throws SQLException {
		System.out.println("POST METHOD");
		System.out.println(student);
		ResponseEntity<String> resp = restTemplate.postForEntity("http://localhost:9090/rbutech/reg", student,
				String.class);
		System.out.println("rest client..");
		String student2 = resp.getBody();
		return student2;
		// return service.saveStudent(student);
	}

	// update
	@PutMapping(value = "/reg")
	public String update(@RequestBody Student student) throws SQLException {
		System.out.println("PUT METHOD");
		System.out.println(student);
		return service.updateStudent(student);
	}

	// delete
	@DeleteMapping(value = "/reg/{id}")
	public String delete(@PathVariable("id") Integer id) throws SQLException {
		System.out.println("DELETE METHOD");
		System.out.println(id);
		return service.deleteStudent(id);
	}

	// localhost:9090/reg/1
	@GetMapping(value = "/reg/{id}")
	public Student find(@PathVariable("id") Integer id) throws SQLException {
		System.out.println("GET METHOD");
		System.out.println(id);
		return service.selectStudent(id);
	}

}
