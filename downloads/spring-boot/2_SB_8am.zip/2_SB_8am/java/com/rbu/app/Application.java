package com.rbu.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

//@SpringBootConfiguration
//@EnableAutoConfiguration
//@ComponentScan(excludeFilters={@Filter(type=CUSTOM, classes={TypeExcludeFilter.class}), @Filter(type=CUSTOM, classes={AutoConfigurationExcludeFilter.class})})
//<context:component-scan basepackage="">
@SpringBootApplication(scanBasePackages = {"com.ds.web","com.ds.service","com.ds.dao","com.ds.config"})
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}
	@Bean
	public RestTemplate createRT() {
		return new RestTemplate();
	}

}
