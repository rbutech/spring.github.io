package com.rbu.app;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {
	public HelloController() {
		System.out.println("HelloController");
	}
	@RequestMapping(value = "/hello",method = RequestMethod.GET)
	public String hello() {
		return "Hello...";
	}

}
