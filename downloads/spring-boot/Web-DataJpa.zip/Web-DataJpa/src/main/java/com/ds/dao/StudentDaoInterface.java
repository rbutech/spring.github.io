package com.ds.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ds.web.Student;
@Repository 
public interface StudentDaoInterface extends JpaRepository<Student, Integer>{
	public Student findByEmail(String email);
	public Student findByName(String name);
	@Query("from Student where address=:address")
	public Student findByAddress(String address);
}
