package com.ds.service;

import java.sql.SQLException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ds.dao.StudentDaoInterface;
import com.ds.web.Student;

@Service
public class StudentService {
	@Autowired
	private StudentDaoInterface dao;

	public StudentService() {
		System.out.println("StudentService");
	}

	public Student saveStudent(Student student) throws SQLException {
		return dao.save(student);
	}

	public Student updateStudent(Student student) throws SQLException {
		return dao.save(student);
	}

	public void deleteStudent(Student student) throws SQLException {
		dao.delete(student);
	}

	public Optional<Student> selectStudent(int id) throws SQLException {
		return dao.findById(id);
	}

	public Student selectbyName(String name) throws SQLException, UserNotFound {
		Student student = dao.findByName(name);
		if (student.getId() != 0)
			return student;
		else
			throw new UserNotFound("No USER FOUND");

	}

	public Student selectbyEmail(String email) throws SQLException, UserNotFound {
		Student student = dao.findByEmail(email);
		try {
			if (student.getId() != 0) {
				return student;
			}

		} catch (Exception e) {
			throw new UserNotFound("No USER FOUND");
		}
		return student;

	}

	public Student selectbyAddress(String address) throws SQLException, UserNotFound {
		Student student = dao.findByAddress(address);
		if (student.getId() != 0)
			return student;
		else
			throw new UserNotFound("No USER FOUND");

	}
}
