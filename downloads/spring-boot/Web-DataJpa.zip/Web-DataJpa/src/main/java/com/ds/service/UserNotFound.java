package com.ds.service;

public class UserNotFound extends Exception {
	private String msg;

	public UserNotFound(String msg) {
		this.msg = msg;
	}

	@Override
	public String toString() {
		return "UserNotFound [msg=" + msg + "]";
	}

}
