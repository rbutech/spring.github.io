package com.ds.web;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.ds.service.UserNotFound;

@ControllerAdvice
public class ExceptionAdvice {
	@ExceptionHandler(NullPointerException.class)
	public ResponseEntity<String> handleNullPointEx() {
		return new ResponseEntity("Object is empty", HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(UserNotFound.class)
	public ResponseEntity<String> handleUserNotFoundEx() {
		return new ResponseEntity("user data not available", HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<String> handleunknnownEx() {
		return new ResponseEntity("unknow issue , we will resolve soon", HttpStatus.BAD_REQUEST);
	}

}
