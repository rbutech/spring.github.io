package com.ds.web;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ds.service.StudentService;
import com.ds.service.UserNotFound;

@RestController
public class StudentController {
	@Autowired
	private StudentService service;

	public StudentController() {
		System.out.println("StudentController");
	}

	// @RequestMapping(value = "/reg", method = RequestMethod.POST)
	// create
	@PostMapping(value = "/reg")
	public Student register(@RequestBody Student student) throws SQLException {
		System.out.println("POST METHOD");
		System.out.println(student);
		return service.saveStudent(student);
	}

	// update
	@PutMapping(value = "/reg")
	public Student update(@RequestBody Student student) throws SQLException {
		System.out.println("PUT METHOD");
		System.out.println(student);
		return service.updateStudent(student);
	}

	// delete
	@DeleteMapping(value = "/reg/{id}")
	public String delete(@PathVariable("id") Integer id) throws SQLException {
		System.out.println("DELETE METHOD");
		System.out.println(id);
		Student std = new Student();
		std.setId(id);
		service.deleteStudent(std);
		return "success";
	}

	// localhost:9090/reg/1
	@GetMapping(value = "/reg/{id}")
	public Student find(@PathVariable("id") Integer id) throws SQLException {
		System.out.println("GET METHOD");
		System.out.println(id);
		return service.selectStudent(id).get();
	}
	@GetMapping(value = "/findByName/{name}")
	public Student findbyName(@PathVariable("name") String name) throws SQLException, UserNotFound {
		System.out.println("GET METHOD");
		System.out.println(name);
		return service.selectbyName(name);
	}
	@GetMapping(value = "/findByEmail/{email}")
	public Student findbyEmail(@PathVariable("email") String email) throws SQLException, UserNotFound {
		System.out.println("GET METHOD");
		System.out.println(email);
		return service.selectbyEmail(email);
	}
	@GetMapping(value = "/findByAddress/{address}")
	public Student findbyAddress(@PathVariable("address") String address) throws SQLException, UserNotFound {
		System.out.println("GET METHOD");
		System.out.println(address);
		return service.selectbyAddress(address);
	}

}
