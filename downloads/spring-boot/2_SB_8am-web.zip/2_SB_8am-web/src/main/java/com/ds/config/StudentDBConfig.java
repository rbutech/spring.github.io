package com.ds.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class StudentDBConfig {
	public StudentDBConfig() {
		System.out.println("StudentDBConfig");
	}

	public String getMessage() {
		return "Hello.. from StudentDBConfig";
	}

	@Bean
	public Connection createConnection() throws ClassNotFoundException, SQLException {
		Class.forName("oracle.jdbc.OracleDriver");
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "admin");
		return con;
	}

}
