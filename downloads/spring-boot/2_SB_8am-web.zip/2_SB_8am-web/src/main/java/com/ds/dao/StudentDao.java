package com.ds.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ds.config.StudentDBConfig;
import com.ds.web.Student;

@Repository
public class StudentDao {
	@Autowired
	private StudentDBConfig config;

	@Autowired
	Connection con;

	public StudentDao() {
		System.out.println("StudentDao");
	}

	public String getMessage() {
		return config.getMessage();
	}

	public String save(Student student) throws SQLException {
		Statement statement = con.createStatement();
		int i = statement.executeUpdate("insert into student_boot_007 values(" + student.getId() + ",'"
				+ student.getName() + "','" + student.getEmail() + "','" + student.getAddress() + "')");
		statement.close();

		if (i != 0)
			return "save success";
		else
			return "save failed";

	}

	public String update(Student student) throws SQLException {
		Statement statement = con.createStatement();
		int i = statement.executeUpdate("update student_boot_007 set name='" + student.getName() + "', email='"
				+ student.getEmail() + "',address='" + student.getAddress() + "' where id=" + student.getId() + "");
		statement.close();

		if (i != 0)
			return "update success";
		else
			return "update failed";

	}

	public String delete(int id) throws SQLException {
		Statement statement = con.createStatement();
		int i = statement.executeUpdate("delete student_boot_007 where id=" + id + "");
		statement.close();
		if (i != 0)
			return "delete success";
		else
			return "delete failed";

	}

	public Student find(int id) throws SQLException {
		Statement statement = con.createStatement();
		ResultSet rs = statement.executeQuery("select * from student_boot_007 where id=" + id + "");
		Student student = new Student();

		while (rs.next()) {
			student.setId(rs.getInt(1));
			student.setName(rs.getString(2));
			student.setEmail(rs.getString(3));
			student.setAddress(rs.getString(4));
		}
		return student;
	}
}
