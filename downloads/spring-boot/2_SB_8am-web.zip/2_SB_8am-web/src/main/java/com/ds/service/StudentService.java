package com.ds.service;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ds.dao.StudentDao;
import com.ds.web.Student;

@Service
public class StudentService {
	@Autowired
	private StudentDao dao;

	public StudentService() {
		System.out.println("StudentService");
	}
	
	public String getMessage() {
		return dao.getMessage();
	}
	
	public String saveStudent(Student student) throws SQLException {
		return dao.save(student);
	}
	public String updateStudent(Student student) throws SQLException {
		return dao.update(student);
	}
	public String deleteStudent(int id) throws SQLException {
		return dao.delete(id);
	}
	public Student selectStudent(int id) throws SQLException {
		return dao.find(id);
	}
}
