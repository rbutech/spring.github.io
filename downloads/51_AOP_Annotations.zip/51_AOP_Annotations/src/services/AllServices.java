package services;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import business.Bank;
@Aspect
public class AllServices {
	
	@Before("execution(* business.Bank.deposite(..))")
	public void myBefore(JoinPoint jp) throws Throwable {
		Logger l = LoggerFactory.getLogger(Bank.class);
		l.info("Before..........before deposite method...");

	}
	@After("execution(* business.Bank.deposite(..))")
	public void myAfter(JoinPoint jp) throws Throwable {
		System.out.println("myBefore method....");
		Logger l = LoggerFactory.getLogger(Bank.class);
		l.info("After..........after deposite method...");
	}
	@Around("execution(* business.Bank.deposite(..))")
	public Object myAround(ProceedingJoinPoint joinPoint) throws Throwable {
		System.out.println("myBefore method....");

		Logger l = LoggerFactory.getLogger(Bank.class);
		l.info("Around..........before deposite method...");

		Object ret = joinPoint.proceed();
		l.info("Around..........after deposite method...");

		return ret;
	}
	@AfterThrowing("execution(* business.Bank.deposite(..))")
	public void myException(JoinPoint jp)throws Throwable
	{
		System.out.println("MyException");
	
	}
	
}
