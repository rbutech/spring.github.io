package web;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class HelloServlet extends HttpServlet {
	Connection con;

	@Override
	public void init(ServletConfig config) throws ServletException {

		try {
			System.out.println("init method");
			Class.forName(config.getInitParameter("driver"));
			con = DriverManager.getConnection(config.getInitParameter("url"), config.getInitParameter("user"),
					config.getInitParameter("pwd"));
			config.getServletContext().setAttribute("con", con);

		} catch (Exception e) {
			// TODO: handle exception
		}
		super.init(config);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String name = req.getParameter("key1");
		try {
			Statement st = con.createStatement();
			st.executeUpdate("insert into USERDATA values('" + name + "')");
			st.close();
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		HttpSession session=req.getSession();
		session.setAttribute("user", name);
		//resp.getWriter().print("<h1> Hello mr/ms :" + name + "</h1>");
		resp.sendRedirect("success.jsp");
	}

	@Override
	public void destroy() {
		try {
			System.out.println("destroy method");
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		super.destroy();
	}
}
