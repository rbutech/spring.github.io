package beans;

public class Honda implements Car {

	@Override
	public void drive() {
	System.out.println("Honda safedriver upto 80kmph");

	}

}
