package com.ds.bo;

import java.util.List;
import java.util.Map;

import com.ds.dao.Student;
import com.ds.dao.StudentDaoInterface;

public class StudentBoImpl implements StudentBo {

	private StudentDaoInterface daoInterface;

	public void setDaoInterface(StudentDaoInterface daoInterface) {
		this.daoInterface = daoInterface;
	}

	@Override
	public int joinStudent(int id, String name, String email, String adddress) {

		return daoInterface.save(id, name, email, adddress);
	}

	@Override
	public int updateExStudent(int id, String name, String email,
			String adddress) {
		return daoInterface.update(id, name, email, adddress);
	}

	@Override
	public int deleteStudent(int id) {
		return daoInterface.delete(id);
	}

	@Override
	public Map getStudentById(int id) {
		return daoInterface.findbyPk(id);
	}

	@Override
	public List getAllStudents() {
		return daoInterface.findAll();
	}
	public Student getStudenObject(int id){
		return daoInterface.findbyObject(id); 
	}


}
