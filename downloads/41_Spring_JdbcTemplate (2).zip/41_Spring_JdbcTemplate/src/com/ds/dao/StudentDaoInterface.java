package com.ds.dao;

import java.util.List;
import java.util.Map;

public interface StudentDaoInterface {
public int save(int id,String name,String email,String adddress);
public int update(int id,String name,String email,String adddress);
public int delete(int id);
public Map findbyPk(int id);
public Student findbyObject(int id);
public List findAll();
}
