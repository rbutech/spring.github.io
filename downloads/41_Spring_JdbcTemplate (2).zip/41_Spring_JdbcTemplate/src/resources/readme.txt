create table student(id number, name varchar2(20),email varchar2(30));
