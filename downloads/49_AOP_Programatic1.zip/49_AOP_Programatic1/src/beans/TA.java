package beans;

import org.springframework.aop.ThrowsAdvice;

public class TA implements ThrowsAdvice 
{
	
	public void afterThrowing(Exception e){
		
		System.out.println("on business Exception="+e.getMessage());
	}

}
