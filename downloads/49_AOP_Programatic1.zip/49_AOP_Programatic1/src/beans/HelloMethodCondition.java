package beans;

import java.lang.reflect.Method;

import org.springframework.aop.support.DefaultPointcutAdvisor;
import org.springframework.aop.support.StaticMethodMatcherPointcut;

public class HelloMethodCondition extends StaticMethodMatcherPointcut {

	@Override
	public boolean matches(Method m, Class c) {
		if (m.getName().equals("hello"))

			return true;
		else
			return false;
	}

}
