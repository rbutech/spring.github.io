package beans;

public class Test {

	public void hello() {
		System.out.println("Hello Business");
	}

	public void hai() {
		System.out.println("Hai Business");
		System.out.println(10 / 0);
	}

}
