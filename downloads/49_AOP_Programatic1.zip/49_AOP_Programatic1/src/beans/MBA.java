package beans;

import java.lang.reflect.Method;

import org.springframework.aop.MethodBeforeAdvice;

public class MBA implements MethodBeforeAdvice {

	@Override
	public void before(Method m, Object[] arg1, Object obj)
			throws Throwable {
	System.out.println("before business");

	}

}
