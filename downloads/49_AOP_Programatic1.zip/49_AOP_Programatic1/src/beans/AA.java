package beans;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;

public class AA implements MethodInterceptor {

	@Override
	public Object invoke(MethodInvocation mi) throws Throwable {
		System.out.println("before from AA ");
		Object ret=mi.proceed();
		System.out.println("after from AA ");
		return ret;
	}

}
