package beans;

public class Engine {
private String enginename;

public void setEnginename(String enginename) {
	this.enginename = enginename;
}
public String getEnginename() {
	return enginename;
}


}
