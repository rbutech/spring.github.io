package beans;

public class Consumer {
	private String fruit;
	private String cap;
	
	public void setCap(String cap) {
		this.cap = cap;
	}
	public void setFruit(String fruit) {
		this.fruit = fruit;
	}
	public void printData(){
		System.out.println("Fruitname="+fruit);
		System.out.println("Capname="+cap);
		
	}
	

}
