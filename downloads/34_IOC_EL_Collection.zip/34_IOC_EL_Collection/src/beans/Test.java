package beans;

import java.util.List;
import java.util.Map;

public class Test {
	private List fruits;
	private Map statecap;

	public void setFruits(List fruits) {
		this.fruits = fruits;
	}

	public void setStatecap(Map statecap) {
		this.statecap = statecap;
	}

	public List getFruits() {
		return fruits;
	}

	public Map getStatecap() {
		return statecap;
	}

}
