package test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import beans.Consumer;
import beans.Test;


public class Client {
public static void main(String[] args) {
	
	ApplicationContext ap=new ClassPathXmlApplicationContext("resources/test.xml");
	Consumer c=(Consumer)ap.getBean("c");
	c.printData();
	
	
	
}
}
