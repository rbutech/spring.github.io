package beans;

class CarC extends Car{

}
