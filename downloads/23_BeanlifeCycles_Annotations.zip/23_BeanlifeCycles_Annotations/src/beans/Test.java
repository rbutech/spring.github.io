package beans;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;


public class Test 
{
	private String name;
	public void setName(String name) {
	System.out.println("setter called");
		this.name = name;
	}
	@PostConstruct
	public void myinit() throws Exception {
		System.out.println("init...");
		
	}
	@PreDestroy
	public void mydestroy() throws Exception {
		System.out.println("Destroy");		
	}
	
	

}
