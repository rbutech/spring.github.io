package test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ds.bo.Bank;

public class Client {
	public static void main(String[] args) {

		ApplicationContext ap = new ClassPathXmlApplicationContext(
				"resources/spring.xml");

		Bank bp=(Bank)ap.getBean("pfb");
		System.out.println(bp);
		int bal=bp.deposite("SBI12345", 5000);
		System.out.println(bal);
	}
}
