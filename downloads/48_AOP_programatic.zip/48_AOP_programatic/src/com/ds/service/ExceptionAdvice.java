package com.ds.service;

import org.springframework.aop.ThrowsAdvice;

public class ExceptionAdvice implements ThrowsAdvice {

	public void afterThrowing(Exception ex) {
		System.out.println(ex);
		System.out.println("exception advice");
	}
	
	
}
