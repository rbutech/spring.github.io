package com.ds.service;

import java.util.Date;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;

import com.ds.bo.Bank;

public class LoggingService implements MethodInterceptor {
	// aroundadvice
	@Override
	public Object invoke(MethodInvocation mi) throws Throwable {

		Bank b = (Bank) mi.getThis();
		System.out.println("Intime=" + new Date());
		// goto business logic

		int finalamount = (Integer) mi.proceed();
		System.out.println("OutTime=" + new Date());
		return finalamount;

	}

}
