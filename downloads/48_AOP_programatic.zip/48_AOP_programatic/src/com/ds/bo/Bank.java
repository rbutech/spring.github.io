package com.ds.bo;

public class Bank
{
	public int amount=5000;
	public String acno="SBI12345";
	
	public int deposite(String acno, int amount) {
		this.amount = this.amount + amount;
		System.out.println("deposite...");
		try {
			Thread.sleep(500);
		} catch (Exception e) {
		}
		this.amount=this.amount/0;
		return this.amount;
	}

}
