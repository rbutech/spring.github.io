package beans;


public class Test 
{
	private String name;
	public void setName(String name) {
	System.out.println("setter called");
		this.name = name;
	}
	
	public void myinit() throws Exception {
		System.out.println("init...");
		
	}
	
	
	public void mydestroy() throws Exception {
		System.out.println("Destroy");		
	}
	
	

}
