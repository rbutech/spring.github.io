package controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

public class HelloController implements Controller {

	@Override
	public ModelAndView handleRequest(HttpServletRequest req,
			HttpServletResponse res) throws Exception {
			
		
		String name = req.getParameter("name");
		String page = "hellosuccess";
		Map m = new HashMap();
		m.put("msg", "Hello...Mr.." + name);

		ModelAndView mav = new ModelAndView(page, m);
		return mav;
	}

}
