package test;

import org.springframework.context.support.GenericXmlApplicationContext;
import org.springframework.core.env.ConfigurableEnvironment;

import beans.Employee;

public class TestIOC {
	public static void main(String[] args) {
		GenericXmlApplicationContext ctx = new GenericXmlApplicationContext();
		ConfigurableEnvironment env = ctx.getEnvironment();
		env.setActiveProfiles("test1");
		ctx.load("resources/spring-context.xml");
		ctx.refresh();

		Employee emp = ctx.getBean("employee1", Employee.class);
		String firstName = emp.getName();
		System.out.println(firstName);
	}
}
