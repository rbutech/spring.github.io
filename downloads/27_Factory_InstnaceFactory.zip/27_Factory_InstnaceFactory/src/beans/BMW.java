package beans;

public class BMW implements Car {

	@Override
	public void drive() {
	System.out.println("safedriver 120 kmph");

	}

}
