package beans;

import javax.annotation.Resource;


public class Car {

@Resource
//@Qualifier(value="e1")
//@Inject
//@Autowired
private Engine engine;

public void printData(){
	System.out.println("ModelYear="+engine.getModelyear());
}


}
