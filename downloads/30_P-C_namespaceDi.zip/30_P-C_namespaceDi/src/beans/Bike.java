package beans;

public class Bike {
	private String bikename;
	private int modelyear;

	public Bike(String bikename) {
		this.bikename = bikename;
	}

	public Bike(int bikename) {
		this.modelyear = bikename;

	}

	public String getBikename() {
		return bikename;
	}

	public int getModelyear() {
		return modelyear;
	}

}
