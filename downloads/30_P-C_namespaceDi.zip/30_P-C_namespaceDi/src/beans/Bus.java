package beans;

public class Bus {
	private String busname;
	private Engine engine;

	public Bus(String busname, Engine engine) {
		this.busname = busname;
		this.engine = engine;

	}

	public String getBusname() {
		return busname;
	}

	public Engine getEngine() {
		return engine;
	}

}
