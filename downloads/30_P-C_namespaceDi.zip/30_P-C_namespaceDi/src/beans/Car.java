package beans;

public class Car {
	private String carname;
	private Engine engine;

	public void setCarname(String carname) {
		this.carname = carname;
	}

	public void setEngine(Engine engine) {
		this.engine = engine;
	}

	public String getCarname() {
		return carname;
	}

	public Engine getEngine() {
		return engine;
	}
}
