package test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import beans.Bike;
import beans.Bus;
import beans.Car;

public class Client {
public static void main(String[] args) {
	
	
	ApplicationContext ap=new ClassPathXmlApplicationContext("resources/test.xml");

	Car c=(Car)	ap.getBean("c");
		System.out.println(c.getCarname());
		System.out.println(c.getEngine().getModelyear());
		
		
	Bus b=(Bus)	ap.getBean("b1");
		System.out.println(b.getBusname());
		System.out.println(b.getEngine().getModelyear());

		Bike bk=(Bike)	ap.getBean("bk");
		System.out.println(bk.getBikename());
		System.out.println(bk.getModelyear());

}


}
