package beans;

public class Car {
private String[] carnames;
private Engine[] engines;

public void setCarnames(String[] carnames) {
	this.carnames = carnames;
}
public void setEngines(Engine[] engines) {
	this.engines = engines;
}
public void printData(){
	System.out.println("---carnames---");
	for(String car:carnames)
	{
		System.out.println(car);
	}
	System.out.println("---Modelyears----");
	for(Engine  e:engines){
		System.out.println(e.getModelyear());
	}
}

}
