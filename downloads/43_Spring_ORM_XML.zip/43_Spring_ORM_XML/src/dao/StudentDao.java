package dao;

import beans.Student;

public interface StudentDao {
public int save(Student student);
public void update(Student student);
public void delete(Student student);
}
