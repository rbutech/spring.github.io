package factory;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.beans.factory.FactoryBean;

public class MyHBSF implements FactoryBean {

	@Override
	public Object getObject() throws Exception {
		Configuration cfg = new Configuration();
		cfg.configure("orm/hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		return sf;
	}

	@Override
	public Class getObjectType() {
		return SessionFactory.class;
	}

	@Override
	public boolean isSingleton() {
		return true;
	}

}
