package beans;

import java.lang.reflect.Method;

import org.springframework.beans.factory.support.MethodReplacer;

public class MyReplacer implements MethodReplacer {

	@Override
	public Object reimplement(Object o, Method m, Object[] param)
			throws Throwable {
		int amount=(Integer)param[0];
		System.out.println("New IntrestRate");
		int intr=(amount*20)/100;
		
		return intr;
	}

}
