package beans;

public class Bank {

	public int calInterest(int amount) {
		int intr = (amount * 10) / 100;
		System.out.println("old calInterest method");
		return intr;
	}

	public void deposite(int amount) {
		int total = calInterest(amount) + amount;
		System.out.println("Total Amount Deposite=" + total);
	}

}
