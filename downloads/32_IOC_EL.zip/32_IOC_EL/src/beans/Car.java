package beans;

public class Car {
	private String modelyear;
	private Engine engine;

	public void setEngine(Engine engine) {
		this.engine = engine;
	}

	public void setModelyear(String modelyear) {
		this.modelyear = modelyear;
	}

	public Engine getEngine() {
		return engine;
	}

	public String getModelyear() {
		return modelyear;
	}

}
