package test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import beans.Test;
import beans.Test1;

public class Client {
	public static void main(String[] args) {

		ApplicationContext ap = new ClassPathXmlApplicationContext(
				"resources/test.xml");
		Test1 t1 = (Test1) ap.getBean("t1");
		System.out.println(t1.getName());
		System.out.println(t1.getEmail());
		System.out.println(t1.getAddress());
		Test t = (Test) ap.getBean("t");
		System.out.println(t.getName());
		System.out.println(t.getEmail());

	}
}
